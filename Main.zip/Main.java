package com.nttdata.Collections.Assign;

import java.util.ArrayList;
import java.util.List;


public class Main {
	
		
		public static void main(String[] args) {
			List<Employees> Emp=new ArrayList<Employees>();
			Emp.add(new Employees(12, "Harshi", 25000, "Blore"));
			Emp.add(new Employees(67, "Prathi", 15000, "Mysore"));
			Emp.add(new Employees(84, "Niki", 35000, "Delhi"));
			Emp.add(new Employees(53, "Bhumi", 20000, "Mumbai"));
			
			Emp.stream().filter(emp->emp.getSalary()>20000).forEach(s->System.out.println(s));
				
		    Emp.stream().map(p->{return(p.getaddress().toLowerCase());}).forEach(System.out::println);
				
			}

	      
	

}
